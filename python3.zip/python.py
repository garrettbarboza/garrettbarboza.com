#!/usr/bin/env python

def main():
  return 0
